# ESMS Builder — ROGEAP Off-Grid Solar Edition

A comprehensive browser-based tool for developing, documenting, and implementing a complete Environmental and Social Management System (ESMS) aligned with the **ROGEAP Off-Grid Solar ESMS Guidelines** and **IFC Performance Standards**.

## Features

- 🌿 Full ESMS development workflow: Screening → Policies → Risk Assessment → Compliance → Management Plans → Implementation Tools → ESAP
- 📖 Built-in Guidelines panel with ROGEAP + IFC references on every section
- 🛠️ 13 ready-to-use implementation tools (Risk Register, Grievance Log, Waste Register, Training Register, etc.)
- 📄 Export to PDF, Word (RTF), and CSV — per section and as a full ESMS document
- 🌐 Trilingual: English | Français | Português (with Google Translate compatibility)
- 💾 Auto-saves all data to browser localStorage

## Project Structure

```
esms-builder/
├── index.html              # Entry HTML with Google Translate meta tags
├── vite.config.js          # Vite build configuration
├── package.json            # Dependencies
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx            # React entry point
    ├── App.jsx             # Main application (2,800+ lines)
    ├── index.css           # Global styles + scrollbar
    └── i18n/
        └── translations.js # EN / FR / PT translations + LangContext
```

## Quick Start on Replit

1. Import this zip into Replit as a **React** project
2. In the Replit Shell, run: `npm install`
3. Run: `npm run dev`
4. Open the preview URL

## Quick Start Locally

```bash
npm install
npm run dev
# Open http://localhost:5173
```

## Build for Production

```bash
npm run build
# Output in dist/
```

## Technology

- **React 18** (Vite)
- **No external UI libraries** — all styles are inline React JSX
- **No backend** — all data stored in browser localStorage
- **Exports**: PDF via browser print, Word via RTF, CSV via data URI

## Alignment

- ROGEAP ESMS Guidelines v01 (ECOWAS/ECREEE)
- IFC Performance Standards (2012)
- IFC ESMS Implementation Toolkit (2015)
- World Bank Environmental and Social Framework (2017)
- GOGLA Consumer Protection Code

## Languages

| Code | Language | ESMS Abbreviation |
|------|----------|-------------------|
| en | English | ESMS |
| fr | Français | SGSE |
| pt | Português | SGAS |

---
Built for GOPA Nigeria / ROGEAP Programme
